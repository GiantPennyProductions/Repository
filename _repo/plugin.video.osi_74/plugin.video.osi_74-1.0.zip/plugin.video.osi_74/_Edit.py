import xbmcaddon

MainBase = 'https://simplekore.com/wp-content/uploads/file-manager/GiantPennyProductions/home.txt'
addon = xbmcaddon.Addon('plugin.video.osi_74')